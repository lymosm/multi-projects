=== Plugin Name ===
Contributors: xtoool.com
Author URI: https://www.xtoool.com
Donate link: https://www.xtoool.com/wordpress/redirecter/
Tags: ads, htaccess, product, image, apache, nginx, post, admin
Requires at least: 5.3
Tested up to: 6.3.2
Stable tag: 1.0.0
Requires PHP: 5.4
License: GPLv3

Xtoool Ads Box helps you create High-converting product bars to engage customers and grow sales.

Are you worried about how to create, manage, and maintain ads bars on many product pages or blog pages? It is indeed a very complicated job, and we are here to solve this problem for you.

With Xtoool Ads Box, you can create high-converting product bars to announce important Products, special offers, and events, engage customers and grow your sales. Not only is it customizable and easy to set up and manage

Features

High-Converting: display the latest events or important products, increase order
Easy To Set Up: easy install & setting, visually add your ads bar
Shortcode insertion: copy the ads bar's shortcode, insert it into the page
Convenient management: you can edit the ads bar of multiple pages at one time

Effect preview: